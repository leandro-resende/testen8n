# Change Log

- fix optional credentials issue in recent n8n versions.
