test('Hello', async () => {
	expect('Hello').toStrictEqual('Hello');
});
